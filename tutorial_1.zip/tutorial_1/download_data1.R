#### Preamble ####
#title: "Download Canadian Elections Data"
#author: "Group 10"
#date: "2024-09-05"
#output: html_document


### Read in the data ###
# Load actual election data
election_data <- read_csv("tutorial_1/table_tableau11.csv")
head(election_data)
tail(election_data)






